<div class="relative">
	<div class="col-md-9 col-bordered">
		<h1>Selamat datang di</h1>
	</div>
	<div class="col-md-3" style="padding: 0px; padding-left: 15px;">
		test
	</div>
</div>