<div class="container relative">
	<?php sidebar_not_login(); ?>
	<div class="col-md-9" style="border: 1px solid #efefef;">
		<h1>Sample</h1>
		<h1>Sample</h1>
		<h1>Sample</h1>
		<h1>Sample</h1>
		<h1>Sample</h1>
		<h1>Sample</h1>
		<h1>Sample</h1>
		<h1>Sample</h1>
		<h1>Sample</h1>
		<h1>Sample</h1>
		<h1>Sample</h1>
	</div>
</div>