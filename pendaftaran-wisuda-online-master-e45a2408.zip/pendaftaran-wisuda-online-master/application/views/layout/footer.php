<div class="footer">
	<div class="container">
		<div class="">Universitas Islam Madura <?php echo date('Y'); ?></div>
	</div>
</div>
