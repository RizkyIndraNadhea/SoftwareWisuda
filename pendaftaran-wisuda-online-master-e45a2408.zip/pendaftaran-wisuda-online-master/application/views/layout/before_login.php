<nav class="navbar navbar-default navbar-static-top sample123">
    <div class="container" style="height: 100px;">
        <div class="navbar-header">
             <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                <span class="sr-only">Toggle Navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <!-- Branding Image -->
            <a class="navbar-brand" href="<?php echo base_url() ?>home">
                <img src="<?php echo base_url() ?>asset/img/icon.png" title='Pendaftaran Wisuda Online' style='width:89px; position: absolute; margin-top: -10px;' alt='Sistem Wisuda'>
                <div class="hidden-xs" style="margin-left: 99px; margin-top: 12px;">
                    <p style="font-size: 28px;">Pendaftaran Wisuda Online</p>
                    <p>Universitas Islam Madura</p>
                </div>
            </a>
        </div>
    </div>
</nav>

<nav class="navbar navbar-default navbar-fixed-top sample12 hide-nav">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                <span class="sr-only">Toggle Navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <!-- Branding Image -->
            <a class="navbar-brand" href="<?php echo base_url() ?>home">
               <img src="<?php echo base_url() ?>asset/img/icon.png" title='Pendaftaran Wisuda Online' style='width:45px; position: absolute; margin-top: -12px;' alt='Sistem Wisuda'>
               <span class="hidden-xs" style="margin-left: 55px;">Pendaftaran Wisuda Online</span>
            </a>
        </div>

        <div class="collapse navbar-collapse" id="app-navbar-collapse">
            <!-- Left Side Of Navbar -->
            <ul class="nav navbar-nav navbar-right">
                <li><a href="login">Daftar</a></li>
                <li><a href="login">Masuk</a></li>
            </ul>
        </div>
    </div>
</nav>